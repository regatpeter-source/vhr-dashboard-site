Write-Host "[Legacy AutoLaunch] Fonction désactivée. Utilise le raccourci VHR Dashboard Pro ou scripts/launch-dashboard-smart.bat." | Out-Null
