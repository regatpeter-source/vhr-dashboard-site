﻿VR Dashboard demo archive

Ce fichier est un exemple de demo zip contenant un petit fichier README et un fichier APK placeholder pour les tests.
