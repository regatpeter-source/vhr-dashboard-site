VHR DASHBOARD - Demo package

To use this demo: open index.html in a browser (double-click) or unzip the package and serve it as static files. The APK is included for Android.

For ADB install: adb install -r vhr-dashboard-demo.apk
